# jetson_stream_and_control.py
import cv2
import socket
import struct
import time
import serial
import select

# ===== 設定 =====
SERVER_IP = "192.168.11.12"   # デスクトップのIP
PORT = 5050
CAM_INDEX = 0
JPEG_QUALITY = 70
FRAME_DELAY = 0.03  # 送信間隔[s]

# Nucleo シリアル
NUCLEO_PORT = "/dev/ttyACM0"   # 実環境に合わせて
BAUD = 115200

# 回転制御キャリブレーション（実機で調整）
seconds_per_degree = 0.02  # 1度当たりの回転秒数（要実測）
rotation_speed_value = 1500  # 連続回転サーボ中立付近の値（Nucleoが扱う任意の値）
# ここでは Nucleo とシンプルコマンドでやり取りする:
# "ROTATE CW <speed>\n"  (回転継続)
# "ROTATE CCW <speed>\n"
# "STOP\n"

# ===== シリアル（Nucleo）準備 =====
try:
    ser = serial.Serial(NUCLEO_PORT, BAUD, timeout=0.1)
    time.sleep(1)
    print("[CLIENT] Nucleoシリアル接続:", NUCLEO_PORT)
except Exception as e:
    ser = None
    print("[CLIENT] Nucleo接続失敗:", e)

# ===== TCP接続（サーバー）準備 =====
client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client_socket.connect((SERVER_IP, PORT))
client_socket.setblocking(False)  # ノンブロッキング recv 用
print("[CLIENT] デスクトップに接続しました:", SERVER_IP)

# カメラ準備
cap = cv2.VideoCapture(CAM_INDEX)
if not cap.isOpened():
    raise RuntimeError("カメラが開けません")

# 起動時は常時回転コマンドを Nucleo に送っておく（1回だけで継続回転する実装を想定）
def send_rotate_cw():
    if ser:
        ser.write(f"ROTATE CW {rotation_speed_value}\n".encode())

def send_rotate_ccw():
    if ser:
        ser.write(f"ROTATE CCW {rotation_speed_value}\n".encode())

def send_stop():
    if ser:
        ser.write(b"STOP\n")

# 初期回転（時計回り）--- 必要なら逆にする
if ser:
    send_rotate_cw()
    print("[CLIENT] Nucleoへ: ROTATE CW (start)")

try:
    while True:
        ret, frame = cap.read()
        if not ret:
            continue

        # エンコードして送信
        result, encoded = cv2.imencode('.jpg', frame, [int(cv2.IMWRITE_JPEG_QUALITY), JPEG_QUALITY])
        if not result:
            continue
        data = encoded.tobytes()
        header = struct.pack('!I', len(data))
        client_socket.sendall(header + data)

        # サーバーからの短い応答をチェック
        ready = select.select([client_socket], [], [], 0.1)
        if ready[0]:
            try:
                resp = client_socket.recv(1024)
                if resp:
                    msg = resp.decode('utf-8', errors='ignore').strip()
                    print(f"[CLIENT] サーバー応答: {msg}")
                    if msg.startswith("FIRE"):
                        # 例: "FIRE <offset_px> <angle_deg> <distance_m> <conf>"
                        parts = msg.split()
                        if len(parts) >= 5:
                            offset_px = float(parts[1])
                            angle_deg = float(parts[2])
                            distance_m = float(parts[3])
                            conf = float(parts[4])
                        else:
                            # フォーマット崩れなら無視
                            continue

                        # 角度が正なら右（CW）、負なら左（CCW）に回す
                        if angle_deg > 1.0:
                            direction = "CW"
                        elif angle_deg < -1.0:
                            direction = "CCW"
                        else:
                            direction = "NONE"

                        # 回転時間を計算（絶対角度に比例）
                        rotate_time = abs(angle_deg) * seconds_per_degree
                        print(f"[CLIENT] angle_deg={angle_deg:.2f} -> rotate_time={rotate_time:.3f}s dir={direction}")

                        # 回転開始（指令送信）
                        if direction == "CW":
                            if ser:
                                ser.write(f"ROTATE CW {rotation_speed_value}\n".encode())
                        elif direction == "CCW":
                            if ser:
                                ser.write(f"ROTATE CCW {rotation_speed_value}\n".encode())
                        else:
                            # 中央なら停止
                            if ser:
                                ser.write(b"STOP\n")

                        # 指定時間だけ回して停止（ブロッキングで確実に向ける）
                        if direction in ("CW", "CCW") and rotate_time > 0:
                            time.sleep(rotate_time)
                            if ser:
                                ser.write(b"STOP\n")
                                print("[CLIENT] Nucleoへ: STOP (arrived)")
                        else:
                            # 中央到達なら即停止
                            if ser:
                                ser.write(b"STOP\n")

                    elif msg.startswith("NOFIRE"):
                        # 火がなければ常時回転を続行（既に回転中なら何もしない）
                        pass
                else:
                    # サーバー切断
                    print("[CLIENT] サーバーから空メッセージ")
                    break

            except BlockingIOError:
                pass
            except Exception as e:
                print("[CLIENT] 応答受信エラー:", e)

        # 送信間隔調整
        time.sleep(FRAME_DELAY)

except KeyboardInterrupt:
    print("[CLIENT] 手動停止")

finally:
    # 停止命令を送って終了
    if ser:
        ser.write(b"STOP\n")
        ser.close()
    cap.release()
    client_socket.close()
    print("[CLIENT] 終了")
