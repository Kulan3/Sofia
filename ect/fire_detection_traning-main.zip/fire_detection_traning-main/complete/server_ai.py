# desktop_ai_server.py
# デスクトップ: 映像受信 -> YOLO + DepthAnything -> 指令（検出情報）をJetsonへ返送

import cv2
import socket
import struct
import numpy as np
import torch
from ultralytics import YOLO
from transformers import AutoImageProcessor, AutoModelForDepthEstimation
import time

# ===== 通信設定 =====
HOST = "0.0.0.0"
PORT = 5050
payload_size = struct.calcsize("!I")  # 4バイトヘッダ

# ===== AI設定 =====
TARGET_LABEL = "fire"  # 学習モデルのラベル名に合わせる
YOLO_MODEL_PATH = r"C:/Users/nakahira/work/miyakawa/training_test_repositry/yolo_depth/models/best.pt"
DEPTH_MODEL_NAME = "depth-anything/Depth-Anything-V2-Small-hf"
SCALE_FILE = r"C:/Users/nakahira/work/miyakawa/training_test_repositry/yolo_depth/scale_base.npy"

print("[SERVER] モデル読み込み中...")
yolo_model = YOLO(YOLO_MODEL_PATH)

device = "cuda" if torch.cuda.is_available() else "cpu"
processor = AutoImageProcessor.from_pretrained(DEPTH_MODEL_NAME)
depth_model = AutoModelForDepthEstimation.from_pretrained(DEPTH_MODEL_NAME).to(device)

try:
    scale_base = np.load(SCALE_FILE)
    print(f"[SERVER] scale_base: {scale_base:.4f}")
except Exception as e:
    print("[SERVER] scale_base 読込失敗:", e, "→ 1.0 を使用")
    scale_base = 1.0

# ===== ソケットサーバー準備 =====
server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
server_socket.bind((HOST, PORT))
server_socket.listen(1)
print(f"[SERVER] 映像受信待機中... ポート:{PORT}")

conn, addr = server_socket.accept()
print("[SERVER] 接続:", addr)

data = b""
frame_count = 0

def px_offset_to_angle_deg(offset_px, frame_width, camera_fov_deg=70.0):
    """ピクセル→角度（deg）換算（単純モデル）"""
    px_per_deg = frame_width / camera_fov_deg
    return offset_px / px_per_deg

try:
    while True:
        # 受信ヘッダ
        while len(data) < payload_size:
            packet = conn.recv(4096)
            if not packet:
                raise ConnectionError("クライアント切断")
            data += packet

        packed_msg_size = data[:payload_size]
        data = data[payload_size:]
        msg_size = struct.unpack('!I', packed_msg_size)[0]

        # 本体受信
        while len(data) < msg_size:
            packet = conn.recv(4096)
            if not packet:
                raise ConnectionError("クライアント切断(フレーム途中)")
            data += packet

        frame_bytes = data[:msg_size]
        data = data[msg_size:]

        # 画像復元
        nparr = np.frombuffer(frame_bytes, dtype=np.uint8)
        frame = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
        if frame is None:
            continue

        frame_count += 1
        h, w = frame.shape[:2]

        # ===== YOLO 推論 =====
        yolo_results = yolo_model(frame, imgsz=320, verbose=False)
        boxes = yolo_results[0].boxes

        # ===== DepthAnything 推論 =====
        inputs = processor(images=frame, return_tensors="pt").to(device)
        with torch.no_grad():
            outputs = depth_model(**inputs)
            depth_raw = outputs.predicted_depth[0].cpu().numpy()
        depth_m = depth_raw / scale_base

        # 可視化用深度マップ
        depth_vis = (depth_raw - depth_raw.min()) / (depth_raw.max() - depth_raw.min() + 1e-8)
        depth_vis = (depth_vis * 255).astype(np.uint8)
        depth_vis = cv2.applyColorMap(depth_vis, cv2.COLORMAP_MAGMA)

        # 検出処理：最初の対象のみ採用
        fire_found = False
        send_msg = "NOFIRE\n"

        for box in boxes:
            x1, y1, x2, y2 = map(int, box.xyxy[0])
            conf = float(box.conf[0])
            cls = int(box.cls[0])
            label = yolo_model.names[cls] if cls in yolo_model.names else str(cls)

            if label == TARGET_LABEL and conf > 0.4:
                # 深度平均
                yy1, yy2 = max(0, y1), min(depth_m.shape[0], y2)
                xx1, xx2 = max(0, x1), min(depth_m.shape[1], x2)
                region = depth_m[yy1:yy2, xx1:xx2]
                mean_depth = float(np.mean(region)) if region.size > 0 else 0.0

                # 画面中心からのピクセルオフセット
                obj_cx = int((x1 + x2) / 2)
                offset_px = obj_cx - (w // 2)
                angle_deg = px_offset_to_angle_deg(offset_px, w, camera_fov_deg=70.0)

                # 送信メッセージ: FIRE <offset_px> <angle_deg> <distance_m> <conf>
                send_msg = f"FIRE {offset_px} {angle_deg:.3f} {mean_depth:.3f} {conf:.3f}\n"
                fire_found = True

                # 可視化
                cv2.rectangle(depth_vis, (x1, y1), (x2, y2), (0,255,0), 2)
                cv2.putText(depth_vis, f"{label} {conf:.2f}", (x1, max(10, y1-10)),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255,255,255), 2)
                break  # 1つ検出でOK

        # デバッグログ
        print(f"[SERVER] frame#{frame_count} -> {send_msg.strip()}")

        # Jetsonへ送信（短いASCII文字列）
        try:
            conn.sendall(send_msg.encode('utf-8'))
        except Exception as e:
            print("[SERVER] 送信エラー:", e)

        # 表示
        cv2.putText(depth_vis, f"Frame:{frame_count}", (10,30),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255,255,255), 2)
        cv2.imshow("AI Stream (DepthVis)", depth_vis)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

except ConnectionError as e:
    print("[SERVER] 接続終了:", e)
except Exception as e:
    print("[SERVER] 例外:", e)
finally:
    conn.close()
    server_socket.close()
    cv2.destroyAllWindows()
    print("[SERVER] 終了")
