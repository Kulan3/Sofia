# ==== evaluate_depthanything.py ====
import numpy as np
import matplotlib.pyplot as plt
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

# ==== 測定データ読み込み ====
data = np.load("depth_eval_data.npz")  # true, pred が入っている想定
true = data["true"]
pred = data["pred"]

# ==== 評価指標 ====
mae = mean_absolute_error(true, pred)
rmse = mean_squared_error(true, pred, squared=False)
r2 = r2_score(true, pred)
scale_error = np.mean(true / pred)

print("===== DepthAnything 距離推定 評価結果 =====")
print(f"MAE:  {mae:.3f} m")
print(f"RMSE: {rmse:.3f} m")
print(f"R²:   {r2:.3f}")
print(f"平均スケール誤差: {scale_error:.3f}")

# ==== 可視化: 実測 vs 推定 ====
plt.figure(figsize=(6,6))
plt.scatter(true, pred, c='blue', s=80, edgecolors='k', label="Predictions")
plt.plot(true, true, 'r--', label="Ideal Line (y=x)")
plt.xlabel("True Distance (m)")
plt.ylabel("Predicted Distance (m)")
plt.title("DepthAnything Distance Estimation")
plt.legend()
plt.grid()
plt.savefig("depth_eval_scatter.png")
plt.show()

# ==== 可視化: 誤差棒グラフ ====
errors = np.abs(true - pred)
plt.figure(figsize=(6,4))
plt.bar(range(len(errors)), errors, color='orange')
plt.xticks(range(len(errors)), [f"{t:.1f}m" for t in true])
plt.ylabel("Absolute Error (m)")
plt.title("Distance Estimation Error by Distance")
plt.grid(axis="y")
plt.savefig("depth_eval_bar.png")
plt.show()

# ==== 可視化: 誤差分布 ====
plt.figure(figsize=(6,4))
plt.hist(errors, bins=10, color='purple', edgecolor='black')
plt.xlabel("Absolute Error (m)")
plt.ylabel("Frequency")
plt.title("Error Distribution")
plt.grid(axis="y")
plt.savefig("depth_eval_hist.png")
plt.show()
