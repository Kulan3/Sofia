# servo_control.py
import Jetson.GPIO as GPIO
import numpy as np
import time

# ==== 設定 ====
SERVO_PIN = 18        # PWMピン (Jetson上のBOARD番号)
DATA_FILE = "target_data.npy"
ANGLE_CENTER = 90.0
ANGLE_MIN = 0.0
ANGLE_MAX = 180.0

# ==== GPIO初期化 ====
GPIO.setmode(GPIO.BOARD)
GPIO.setup(SERVO_PIN, GPIO.OUT)
pwm = GPIO.PWM(SERVO_PIN, 50)  # 50Hz
pwm.start(7.5)  # 中央位置

def set_servo_angle(angle):
    """角度をPWMデューティに変換"""
    duty = 2.5 + (angle / 18.0)
    pwm.ChangeDutyCycle(duty)
    time.sleep(0.02)

print("[INFO] サーボ制御開始（Ctrl+Cで終了）")

try:
    angle = ANGLE_CENTER
    while True:
        try:
            data = np.load(DATA_FILE, allow_pickle=True).item()
            offset_x = data["x_offset"]
            distance = data["distance"]

            # ピクセル→角度変換 (例: 10px ≈ 1°)
            angle_offset = offset_x / 10.0
            target_angle = ANGLE_CENTER - angle_offset
            target_angle = np.clip(target_angle, ANGLE_MIN, ANGLE_MAX)

            set_servo_angle(target_angle)
            print(f"角度: {target_angle:.1f}°, 距離: {distance:.2f} m")

        except FileNotFoundError:
            print("[WARN] target_data.npyが見つかりません。AI検出が起動中か確認してください。")
        
        time.sleep(0.1)

except KeyboardInterrupt:
    print("\n[INFO] 停止しました。")
    pwm.stop()
    GPIO.cleanup()
