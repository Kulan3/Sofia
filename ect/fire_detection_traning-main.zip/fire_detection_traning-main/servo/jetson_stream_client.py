# jetson_stream_client.py
import cv2
import socket
import struct
import time

SERVER_IP = "192.168.0.10"  # ← デスクトップのIPに合わせる
PORT = 5000

cap = cv2.VideoCapture(0)
if not cap.isOpened():
    raise RuntimeError("カメラが開けません")

client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client_socket.connect((SERVER_IP, PORT))
print(f"接続しました: {SERVER_IP}:{PORT}")

try:
    while True:
        ret, frame = cap.read()
        if not ret:
            break

        # JPEG圧縮してバイト化
        result, encoded = cv2.imencode('.jpg', frame, [int(cv2.IMWRITE_JPEG_QUALITY), 70])
        if not result:
            continue
        data = encoded.tobytes()
        # 4バイトのネットワークバイトオーダで長さを送る
        message_size = struct.pack("!I", len(data))
        client_socket.sendall(message_size + data)

        # 適度なスリープ（必要に応じて調整）
        time.sleep(0.01)

except Exception as e:
    print("[ERROR] クライアント例外:", e)
finally:
    cap.release()
    client_socket.close()
    print("切断しました")
