# desktop_ai_server.py
import cv2
import socket
import struct
import torch
import numpy as np
from ultralytics import YOLO
from transformers import AutoImageProcessor, AutoModelForDepthEstimation

# ===== 通信設定 =====
HOST = "0.0.0.0"
PORT = 5000

# ===== AIモデル設定 =====
TARGET_LABEL = "fire"
SCALE_FILE = "scale_base.npy"

print("[INFO] モデル読み込み中...")
yolo_model = YOLO("yolov8n.pt")
model_name = "depth-anything/Depth-Anything-V2-Small-hf"
device = "cuda" if torch.cuda.is_available() else "cpu"
processor = AutoImageProcessor.from_pretrained(model_name)
depth_model = AutoModelForDepthEstimation.from_pretrained(model_name).to(device)
scale_base = np.load(SCALE_FILE)
print(f"[INFO] スケール係数: {scale_base:.4f}")

# ===== ソケットサーバー設定 =====
server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
server_socket.bind((HOST, PORT))
server_socket.listen(1)
print(f"[INFO] 映像受信待機中... ポート: {PORT}")

conn, addr = server_socket.accept()
print(f"[INFO] 接続: {addr}")

data = b""
payload_size = struct.calcsize("!I")  # 固定: 4バイト (network byte order)

try:
    while True:
        # --- ヘッダー受信（4バイト） ---
        while len(data) < payload_size:
            packet = conn.recv(4096)
            if not packet:
                raise ConnectionError("クライアントが切断しました")
            data += packet

        packed_msg_size = data[:payload_size]
        data = data[payload_size:]
        msg_size = struct.unpack("!I", packed_msg_size)[0]

        # --- フレーム本体受信 ---
        while len(data) < msg_size:
            packet = conn.recv(4096)
            if not packet:
                raise ConnectionError("クライアントが切断しました（フレーム途中）")
            data += packet

        frame_data = data[:msg_size]
        data = data[msg_size:]

        # --- バイト列を画像に復元 ---
        nparr = np.frombuffer(frame_data, dtype=np.uint8)
        frame = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
        if frame is None:
            print("[WARN] フレームのデコードに失敗しました")
            continue

        # ===== AI推論 =====
        yolo_results = yolo_model(frame, imgsz=320, verbose=False)
        boxes = yolo_results[0].boxes

        inputs = processor(images=frame, return_tensors="pt").to(device)
        with torch.no_grad():
            outputs = depth_model(**inputs)
            depth_raw = outputs.predicted_depth[0].cpu().numpy()
        depth_m = depth_raw / scale_base

        depth_vis = (depth_raw - depth_raw.min()) / (depth_raw.max() - depth_raw.min())
        depth_vis = (depth_vis * 255).astype(np.uint8)
        depth_vis = cv2.applyColorMap(depth_vis, cv2.COLORMAP_MAGMA)

        for box in boxes:
            x1, y1, x2, y2 = map(int, box.xyxy[0])
            conf = float(box.conf[0])
            cls = int(box.cls[0])
            label = yolo_model.names[cls]
            if label == TARGET_LABEL:
                region = depth_m[y1:y2, x1:x2]
                mean_depth = np.mean(region) if region.size > 0 else 0
                cv2.rectangle(depth_vis, (x1, y1), (x2, y2), (0, 255, 0), 2)
                text = f"{label} {conf:.2f} | {mean_depth:.2f} m"
                cv2.putText(depth_vis, text, (x1, y1 - 10),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)

        h, w = depth_m.shape
        center_region = depth_m[h//2-10:h//2+10, w//2-10:w//2+10]
        center_distance = np.mean(center_region)
        cv2.putText(depth_vis, f"Center: {center_distance:.2f} m", (10, 30),
                    cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 2)

        cv2.imshow('AI Stream (YOLO + DepthAnything)', depth_vis)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

except ConnectionError as e:
    print("[INFO] 接続終了:", e)
except Exception as e:
    print("[ERROR] サーバー例外:", e)
finally:
    conn.close()
    server_socket.close()
    cv2.destroyAllWindows()
