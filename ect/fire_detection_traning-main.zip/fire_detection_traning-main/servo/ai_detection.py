# ai_detection.py
import cv2
import torch
import numpy as np
from ultralytics import YOLO
from transformers import AutoImageProcessor, AutoModelForDepthEstimation

# ==== 設定 ====
TARGET_LABEL = "chair"   # 追跡対象
SCALE_FILE = "scale_base.npy"
OUTPUT_FILE = "target_data.npy"

# ==== モデル読み込み ====
yolo_model = YOLO("yolov8n.pt")

model_name = "depth-anything/Depth-Anything-V2-Small-hf"
device = "cuda" if torch.cuda.is_available() else "cpu"
processor = AutoImageProcessor.from_pretrained(model_name)
depth_model = AutoModelForDepthEstimation.from_pretrained(model_name).to(device)

# ==== キャリブレーション係数 ====
scale_base = np.load(SCALE_FILE)
print(f"[INFO] ロードしたスケール係数: {scale_base:.4f}")

# ==== カメラ起動 ====
cap = cv2.VideoCapture(0)
if not cap.isOpened():
    raise RuntimeError("カメラが認識されていません")

print("[INFO] AI検出開始。'q'キーで終了します。")

while True:
    ret, frame = cap.read()
    if not ret:
        break

    # YOLO検出
    yolo_results = yolo_model(frame, imgsz=320, verbose=False)
    boxes = yolo_results[0].boxes

    # DepthAnythingで深度取得
    inputs = processor(images=frame, return_tensors="pt").to(device)
    with torch.no_grad():
        outputs = depth_model(**inputs)
        depth_raw = outputs.predicted_depth[0].cpu().numpy()
    depth_m = depth_raw / scale_base

    # 初期値（何も検出されない場合）
    offset_x = 0
    mean_depth = 0

    # 検出物体の中で対象ラベルを探す
    for box in boxes:
        x1, y1, x2, y2 = map(int, box.xyxy[0])
        conf = float(box.conf[0])
        cls = int(box.cls[0])
        label = yolo_model.names[cls]

        if label == TARGET_LABEL and conf > 0.5:
            region = depth_m[y1:y2, x1:x2]
            mean_depth = np.mean(region)

            frame_center_x = frame.shape[1] // 2
            object_center_x = int((x1 + x2) / 2)
            offset_x = object_center_x - frame_center_x

            # 可視化
            cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 255, 0), 2)
            text = f"{label} {conf:.2f} | {mean_depth:.2f}m"
            cv2.putText(frame, text, (x1, y1 - 10),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)

            break  # 1つ目の対象だけ追跡

    # 中央表示
    cv2.putText(frame, f"Offset: {offset_x}px  Depth: {mean_depth:.2f}m",
                (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 255, 255), 2)

    # === 座標情報を保存 ===
    np.save(OUTPUT_FILE, {"x_offset": offset_x, "distance": mean_depth})

    # 画面表示
    cv2.imshow("YOLO + DepthAnything", frame)

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
print("[INFO] 検出を終了しました。")
