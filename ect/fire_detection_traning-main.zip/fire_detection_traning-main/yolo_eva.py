# ==== evaluate_yolo_fire.py ====
from ultralytics import YOLO
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np

# ======== 設定 ========
model_path = "best.pt"        
data_yaml = "data.yaml"       
output_dir = "yolo_eval_results"

# ======== 評価 ========
model = YOLO(model_path)
metrics = model.val(data=data_yaml, split="test", save_json=True, project=output_dir)

print("\n===== YOLO 評価結果 =====")
print(f"mAP50: {metrics.box.map50:.3f}")
print(f"mAP50-95: {metrics.box.map:.3f}")
print(f"Precision: {metrics.box.mp:.3f}")
print(f"Recall: {metrics.box.mr:.3f}")

# ======== 可視化: Precision-Recall曲線 ========
plt.figure(figsize=(6,5))
for i, c in enumerate(metrics.box.pr_curve):
    plt.plot(np.linspace(0, 1, len(c)), c, label=f"Class {i}")
plt.xlabel("Recall")
plt.ylabel("Precision")
plt.title("Precision-Recall Curve")
plt.legend()
plt.grid()
plt.savefig(f"{output_dir}/precision_recall_curve.png")
plt.show()

# ======== 可視化: Confusion Matrix ========
cm = metrics.confusion_matrix
plt.figure(figsize=(5,4))
sns.heatmap(cm, annot=True, fmt=".2f", cmap="Blues")
plt.title("Confusion Matrix")
plt.xlabel("Predicted")
plt.ylabel("True")
plt.savefig(f"{output_dir}/confusion_matrix.png")
plt.show()
