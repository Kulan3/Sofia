import cv2
import torch
import numpy as np
import time
import matplotlib.pyplot as plt
import pandas as pd
from ultralytics import YOLO
from transformers import AutoImageProcessor, AutoModelForDepthEstimation

# ==== モデルロード ====
yolo_model = YOLO("yolov8n.pt")  #汎用モデルこれを火に置き換える
depth_model_name = "depth-anything/Depth-Anything-V2-Small-hf"
processor = AutoImageProcessor.from_pretrained(depth_model_name)
depth_model = AutoModelForDepthEstimation.from_pretrained(depth_model_name)
device = "cuda" if torch.cuda.is_available() else "cpu"
depth_model = depth_model.to(device)

# ==== キャリブレーション係数 ====
scale_base = np.load("scale_base.npy")

# ==== 実験設定 ====
true_distances = [0.5, 1.0, 1.5, 2.0]  # 実測距離[m]
label_target = "bottle"  # キャリブレーション対象ラベル

results_data = []

cap = cv2.VideoCapture(0)
cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)

print("=== 評価開始 ===")
print("対象物を指定距離に置いて、's'キーで距離サンプルを取得")

i = 0
while True:
    ret, frame = cap.read()
    if not ret:
        break

    start_time = time.time()

    # YOLO物体検出
    results = yolo_model(frame, verbose=False)
    boxes = results[0].boxes

    # DepthAnything推論
    inputs = processor(images=frame, return_tensors="pt").to(device)
    with torch.no_grad():
        depth_out = depth_model(**inputs)
        depth_raw = depth_out.predicted_depth[0].cpu().numpy()
    depth_m = depth_raw / scale_base  # 補正

    fps = 1.0 / (time.time() - start_time)

    depth_vis = (depth_raw - depth_raw.min()) / (depth_raw.max() - depth_raw.min())
    depth_vis = (depth_vis * 255).astype(np.uint8)
    depth_vis = cv2.applyColorMap(depth_vis, cv2.COLORMAP_MAGMA)

    box_depth = None
    if boxes is not None and len(boxes) > 0:
        for box in boxes:
            cls = int(box.cls[0])
            conf = float(box.conf[0])
            label = yolo_model.names[cls]
            if label != label_target:
                continue
            x1, y1, x2, y2 = map(int, box.xyxy[0])
            cx, cy = (x1 + x2)//2, (y1 + y2)//2
            cv2.rectangle(depth_vis, (x1, y1), (x2, y2), (255,255,255), 2)
            cv2.putText(depth_vis, f"{label} {conf:.2f}", (x1, y1-5),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255,255,255), 2)
            box_depth = np.mean(depth_m[y1:y2, x1:x2])
            break

    if box_depth:
        cv2.putText(depth_vis, f"Pred: {box_depth:.2f}m", (10, 30),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255,255,255), 2)
        cv2.putText(depth_vis, f"Target: {true_distances[i]}m", (10, 60),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255,255,255), 2)
        cv2.putText(depth_vis, f"FPS: {fps:.1f}", (10, 90),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255,255,255), 2)

    cv2.imshow("YOLO+Depth Evaluation", depth_vis)

    key = cv2.waitKey(1)
    if key & 0xFF == ord('s') and box_depth:
        error = abs(true_distances[i] - box_depth)
        results_data.append({
            "true_distance": true_distances[i],
            "pred_distance": box_depth,
            "error": error,
            "fps": fps
        })
        print(f"[{i+1}] 距離: {true_distances[i]}m → 推定: {box_depth:.2f}m (誤差: {error:.2f}m)")
        i += 1
        if i >= len(true_distances):
            print("全距離の評価完了！")
            break
    elif key & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()

# ==== 結果解析 ====
df = pd.DataFrame(results_data)
if not df.empty:
    mae = np.mean(df["error"])
    rmse = np.sqrt(np.mean(df["error"]**2))
    r2 = 1 - np.sum((df["pred_distance"] - df["true_distance"])**2) / np.sum((df["true_distance"] - np.mean(df["true_distance"]))**2)
    mean_fps = np.mean(df["fps"])

    print("\n=== 評価結果 ===")
    print(df)
    print(f"MAE: {mae:.3f} m")
    print(f"RMSE: {rmse:.3f} m")
    print(f"R²: {r2:.3f}")
    print(f"平均FPS: {mean_fps:.1f}")

    # ==== グラフ描画 ====
    plt.figure(figsize=(10,5))
    plt.subplot(1,2,1)
    plt.scatter(df["true_distance"], df["pred_distance"], color='blue')
    plt.plot([0, max(true_distances)], [0, max(true_distances)], 'r--')
    plt.xlabel("True Distance [m]")
    plt.ylabel("Predicted Distance [m]")
    plt.title("True vs Predicted Distance")

    plt.subplot(1,2,2)
    plt.bar(df["true_distance"], df["error"], color='orange')
    plt.xlabel("True Distance [m]")
    plt.ylabel("Absolute Error [m]")
    plt.title("Prediction Error per Distance")

    plt.tight_layout()
    plt.show()
else:
    print("データが記録されていません。")
